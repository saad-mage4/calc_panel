-- MariaDB dump 10.19  Distrib 10.6.15-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: mage4dev_panel
-- ------------------------------------------------------
-- Server version	10.6.15-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pet_sitter`
--

DROP TABLE IF EXISTS `pet_sitter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_sitter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pet_name` varchar(255) NOT NULL,
  `charges` float(8,2) NOT NULL,
  `services_offer` text NOT NULL,
  `status` enum('pending','approve','active','rejected','expired') NOT NULL DEFAULT 'pending',
  `sitter_id` bigint(20) NOT NULL,
  `owner_id` bigint(20) NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `days` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sitter_id` (`sitter_id`),
  CONSTRAINT `pet_sitter_ibfk_1` FOREIGN KEY (`sitter_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_sitter`
--

LOCK TABLES `pet_sitter` WRITE;
/*!40000 ALTER TABLE `pet_sitter` DISABLE KEYS */;
INSERT INTO `pet_sitter` (`id`, `pet_name`, `charges`, `services_offer`, `status`, `sitter_id`, `owner_id`, `start_date`, `end_date`, `days`) VALUES (27,'Dog',3.00,'walk, food, care','active',1,5,'2023-09-19','2023-09-22',3);
/*!40000 ALTER TABLE `pet_sitter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `dob` date NOT NULL DEFAULT current_timestamp(),
  `address` text NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `role` enum('admin','owner','sitter','member') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `email`, `password`, `contact`, `dob`, `address`, `city`, `state`, `zip`, `status`, `role`) VALUES (1,'nuhox','abc@gmail.com','4297f44b13955235245b2497399d7a93','+1 (732) 854-2362','1980-07-28','Qui quo in dicta des','Magnam blanditiis re','Colorado','39433','0','member'),(2,'pugol','starizpk@gmail.com','599844e2e91c9299ef5fc49eabf4e651','+1 (146) 274-9618','2015-02-28','Deleniti at in disti','Illum suscipit porr','Massachusetts','89303','0','sitter'),(5,'test2','abc1@gmail.com','4297f44b13955235245b2497399d7a93','+1 (363) 114-8494','2022-10-03','Est aut quo esse e','Ut est et nihil quae','Oklahoma','44238','0','owner'),(6,'Pet Owner','petowner@tamecare.com','efa708fb30c6d9497a31ee9bd7d1890b','123456','2000-11-11','xuz','xyz','Hawaii','78789','0','owner'),(7,'Pet Sitter','petsitter@tamecare.com','9dcd827aaf5069b805e60e3480af5ef9','123','2023-07-06','fdsfsd','fdfsd','Kansas','rwerew','0','sitter'),(8,'admin','admin@tamecare.com','4297f44b13955235245b2497399d7a93','+1 (774) 466-1908','2006-12-27','Magni quae et enim h','Deserunt Nam nobis s','Alaska','17686','0','admin'),(9,'John Doe','asim_@hotmail.com','dc647eb65e6711e155375218212b3964','9192280197','1973-11-26','5904 Squeezepenny Ln','MCKINNEY','Texas','75070','0','sitter');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mage4dev_panel'
--

--
-- Dumping routines for database 'mage4dev_panel'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_pet_owners_requests` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`mage4dev`@`localhost` PROCEDURE `get_pet_owners_requests`(IN `sitter_id` BIGINT)
SELECT
p.id,
p.pet_name,
p.charges,
p.services_offer,
p.status,
p.days,
p.owner_id
FROM pet_sitter p
WHERE p.sitter_id=sitter_id AND p.owner_id!=0 ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `list_pet_sitters` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`mage4dev`@`localhost` PROCEDURE `list_pet_sitters`(IN `animal` VARCHAR(255))
SELECT
p.id AS 'id',
p.pet_name AS 'petName',
p.charges AS 'charges',
p.services_offer AS 'services',
p.status AS 'status',
p.sitter_id AS 'sid',
p.owner_id AS 'ownerId',
u.username AS 'sitterName'
FROM pet_sitter p
INNER JOIN users u
WHERE p.sitter_id=u.id AND p.status='approve' AND p.pet_name=animal ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `owners_list_admin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`mage4dev`@`localhost` PROCEDURE `owners_list_admin`()
SELECT
p.id AS 'pID',
p.pet_name AS 'petName',
p.charges AS 'charges',
p.services_offer AS 'services',
p.status AS 'status',
p.start_date AS 'startDate',
p.end_date AS 'endDate',
p.sitter_id AS 'sitterID',
p.days AS 'days',
u.username AS 'ownerName'
FROM pet_sitter p
INNER JOIN users u
WHERE p.owner_id=u.id ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pet_sitter_list` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`mage4dev`@`localhost` PROCEDURE `pet_sitter_list`(IN `sitter_id` BIGINT)
SELECT
p.id AS 'pID',
p.pet_name AS 'petName',
p.charges AS 'charges',
p.services_offer AS 'services',
p.status AS 'status',
p.start_date AS 'startDate',
p.end_date AS 'endDate',
p.owner_id AS 'oID',
p.sitter_id AS 'sID',
p.days AS 'days',
u.username AS 'u'
FROM pet_sitter p
INNER JOIN users u
WHERE CASE WHEN p.owner_id=0 THEN p.sitter_id=u.id ELSE p.owner_id=u.id END AND p.sitter_id=sitter_id ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `pet_sitter_list_admin` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`mage4dev`@`localhost` PROCEDURE `pet_sitter_list_admin`()
SELECT
p.id AS 'pID',
p.pet_name AS 'petName',
p.charges AS 'charges',
p.services_offer AS 'services',
p.status AS 'status',
u.username AS 'sitterName'
FROM pet_sitter p
INNER JOIN users u
WHERE p.sitter_id=u.id ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `services_accepted` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
DELIMITER ;;
CREATE DEFINER=`mage4dev`@`localhost` PROCEDURE `services_accepted`(IN `owner_id` BIGINT)
SELECT
p.id AS 'pID',
p.pet_name AS 'petName',
p.charges AS 'charges',
p.services_offer AS 'services',
p.status AS 'status',
p.start_date AS 'startDate',
p.end_date AS 'endDate',
p.days AS 'days',
u.username AS 'sitterName'
FROM pet_sitter p
INNER JOIN users u
WHERE p.sitter_id=u.id AND p.owner_id=owner_id AND (p.status='active' OR p.status='expired') ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `test` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`mage4dev`@`localhost` PROCEDURE `test`()
SELECT * FROM test ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-04 19:26:02
